package com.example.recycle

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
